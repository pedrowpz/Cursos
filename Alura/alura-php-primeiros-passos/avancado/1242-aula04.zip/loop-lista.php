<?php

$idadeList = [23, 19, 25, 30, 41, 18, 21, 35];

for ($i = 0; $i < count($idadeList); $i++) {
    echo $idadeList[$i] . PHP_EOL;
}
