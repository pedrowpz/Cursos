<?php

$idade = 21;
$salario = 1000.301;
$divisao = 10 / 3;

$divisao = 3;

$texto = "Olá mundo";

$verdadeiro = true;
$falso = false;

echo gettype($verdadeiro);
