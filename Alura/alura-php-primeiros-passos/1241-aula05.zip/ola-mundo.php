<?php

echo "Olá mundo!";
